"""
rag.py — Índice FAISS con el FAQ interno del Centro MedImage.
Usa Google Gemini Embeddings. El índice se construye una sola vez y se persiste en disco.
"""

import os
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document

# ---------------------------------------------------------------------------
# FAQ interno — documentos fuente
# ---------------------------------------------------------------------------
FAQ_DOCS: list[Document] = [
    Document(
        page_content=(
            "El Centro MedImage atiende de lunes a viernes de 08:00 a 19:00 horas "
            "y sábados de 09:00 a 14:00 horas. No hay atención los días domingos ni feriados."
        ),
        metadata={"fuente": "FAQ_interna"},
    ),
    Document(
        page_content=(
            "Para una resonancia magnética no necesita preparación especial en la mayoría de los casos. "
            "Si usa marcapasos, implantes metálicos o clips cerebrales, debe informarlo antes del examen."
        ),
        metadata={"fuente": "FAQ_interna"},
    ),
    Document(
        page_content=(
            "Para un TAC con contraste intravenoso (IV) se requiere ayuno de 4 horas previo al examen "
            "y un examen de creatinina sérica reciente (no mayor a 3 meses). "
            "Además debe contar con orden médica."
        ),
        metadata={"fuente": "FAQ_interna"},
    ),
    Document(
        page_content=(
            "Para todo examen de imágenes se requiere orden médica vigente. "
            "Sin ella no se puede realizar el procedimiento."
        ),
        metadata={"fuente": "FAQ_interna"},
    ),
    Document(
        page_content=(
            "El Centro MedImage está ubicado en Av. Colón 2383, Valparaíso. "
            "El tiempo de cada examen es de 60 minutos."
        ),
        metadata={"fuente": "FAQ_interna"},
    ),
    Document(
        page_content=(
            "La resonancia magnética es un examen seguro que no usa radiación ionizante. "
            "Utiliza campos magnéticos y ondas de radio para obtener imágenes del interior del cuerpo."
        ),
        metadata={"fuente": "FAQ_interna"},
    ),
    Document(
        page_content=(
            "El TAC (tomografía axial computarizada) sí utiliza radiación ionizante (rayos X). "
            "Se usa para obtener imágenes de mayor detalle en menor tiempo."
        ),
        metadata={"fuente": "FAQ_interna"},
    ),
    Document(
        page_content=(
            "Las citas se pueden cancelar hasta 24 horas antes del examen llamando al centro "
            "o mediante el sistema de agendamiento en línea."
        ),
        metadata={"fuente": "FAQ_interna"},
    ),
    Document(
        page_content=(
            "Los resultados de los exámenes están disponibles en 24 a 48 horas hábiles. "
            "Se pueden retirar en el centro o solicitar envío digital."
        ),
        metadata={"fuente": "FAQ_interna"},
    ),
    Document(
        page_content="Se aceptan órdenes de Fonasa e Isapres. Consulte por los convenios vigentes directamente en recepción.",
        metadata={"fuente": "FAQ_interna"},
    ),
    Document(
        page_content=(
            "Si es paciente con claustrofobia severa o ansiedad, infórmelo al momento de agendar. "
            "Se pueden coordinar alternativas o apoyo previo al examen."
        ),
        metadata={"fuente": "FAQ_interna"},
    ),
    Document(
        page_content=(
            "Los niños menores de 6 años generalmente requieren sedación para la resonancia magnética. "
            "Esto debe ser coordinado previamente con el médico tratante."
        ),
        metadata={"fuente": "FAQ_interna"},
    ),
    Document(
        page_content=(
            "Los precios de los exámenes varían según el tipo y la cobertura del seguro. "
            "Consulte directamente en recepción o llame al centro para obtener un presupuesto."
        ),
        metadata={"fuente": "FAQ_interna"},
    ),
    Document(
        page_content=(
            "El teléfono de contacto del Centro MedImage es el (32) 2456 789. "
            "También puede escribir al correo contacto@medimage.cl."
        ),
        metadata={"fuente": "FAQ_interna"},
    ),
]

INDEX_PATH = "faiss_index"
_retriever = None


def get_retriever():
    """Retorna el retriever FAISS (singleton). Construye el índice si no existe en disco."""
    global _retriever
    if _retriever is not None:
        return _retriever

    embeddings = GoogleGenerativeAIEmbeddings(model="models/gemini-embedding-001")

    if os.path.exists(INDEX_PATH):
        store = FAISS.load_local(
            INDEX_PATH, embeddings, allow_dangerous_deserialization=True
        )
    else:
        print("[RAG] Construyendo índice FAISS por primera vez…")
        store = FAISS.from_documents(FAQ_DOCS, embeddings)
        store.save_local(INDEX_PATH)
        print(f"[RAG] Índice guardado en '{INDEX_PATH}/'")

    _retriever = store.as_retriever(search_kwargs={"k": 3})
    return _retriever
