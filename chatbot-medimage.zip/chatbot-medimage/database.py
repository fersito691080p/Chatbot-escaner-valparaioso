"""
database.py — SQLite setup para el chatbot MedImage.
Gestiona dos tablas: citas (agendamiento) e historial_conversacion (memoria largo plazo).
"""

import sqlite3
from datetime import datetime

DB_PATH = "medimage.db"


def get_conn() -> sqlite3.Connection:
    """Retorna una conexión abierta a la base de datos."""
    return sqlite3.connect(DB_PATH)


def init_db() -> None:
    """Crea las tablas si no existen. Se llama una sola vez al arrancar el servidor."""
    conn = get_conn()
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS citas (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre       TEXT NOT NULL,
            rut          TEXT NOT NULL,
            fecha        TEXT NOT NULL,
            hora         TEXT NOT NULL,
            tipo_examen  TEXT NOT NULL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS historial_conversacion (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp  TEXT NOT NULL,
            session_id TEXT NOT NULL,
            rol        TEXT NOT NULL,
            mensaje    TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()


def guardar_mensaje(session_id: str, rol: str, mensaje: str) -> None:
    """Guarda un mensaje (user / assistant) en el historial SQLite."""
    conn = get_conn()
    c = conn.cursor()
    c.execute(
        "INSERT INTO historial_conversacion (timestamp, session_id, rol, mensaje) VALUES (?, ?, ?, ?)",
        (datetime.now().isoformat(), session_id, rol, mensaje),
    )
    conn.commit()
    conn.close()


def obtener_historial(session_id: str, limite: int = 10) -> list[dict]:
    """Retorna los últimos `limite` mensajes de una sesión."""
    conn = get_conn()
    c = conn.cursor()
    c.execute(
        """
        SELECT timestamp, rol, mensaje FROM historial_conversacion
        WHERE session_id = ?
        ORDER BY id DESC LIMIT ?
        """,
        (session_id, limite),
    )
    rows = c.fetchall()
    conn.close()
    return [{"timestamp": r[0], "rol": r[1], "mensaje": r[2]} for r in reversed(rows)]
