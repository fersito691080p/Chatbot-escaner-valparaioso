"""
main.py — Servidor FastAPI para el chatbot MedImage.

Expone:
  GET  /          → sirve static/index.html (interfaz de chat)
  POST /chat      → invoca el agente y retorna la respuesta
  GET  /health    → verificación de estado del servidor
"""

import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from dotenv import load_dotenv

# Carga las variables del archivo .env antes de importar módulos del agente
load_dotenv()

# Activar LangSmith si hay clave disponible
if os.getenv("LANGSMITH_API_KEY"):
    os.environ["LANGCHAIN_TRACING_V2"] = "true"
    os.environ["LANGCHAIN_PROJECT"] = os.getenv(
        "LANGCHAIN_PROJECT", "chatbot-resonancia-v2"
    )
    print("[LangSmith] Trazabilidad activada →", os.environ["LANGCHAIN_PROJECT"])


# ---------------------------------------------------------------------------
# Lifespan: inicialización al arrancar el servidor
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Inicializa la BD, el índice FAISS y el agente en el arranque."""
    from database import init_db
    from rag import get_retriever
    from agent import get_agent

    print("[Startup] Inicializando base de datos…")
    init_db()

    print("[Startup] Cargando índice FAISS…")
    get_retriever()  # construye/carga el índice (puede tardar ~10 s la primera vez)

    print("[Startup] Inicializando agente LangGraph…")
    get_agent()  # precalienta el LLM y registra las herramientas

    print("[Startup] ✅ Sistema listo en http://localhost:8000")
    yield
    # (cleanup al apagar — nada necesario aquí)


# ---------------------------------------------------------------------------
# App FastAPI
# ---------------------------------------------------------------------------
app = FastAPI(
    title="MedImage Chatbot API",
    description="Asistente virtual del Centro de Resonancia y Scanner MedImage",
    version="2.0.0",
    lifespan=lifespan,
)

# Servir archivos estáticos (index.html, etc.)
app.mount("/static", StaticFiles(directory="static"), name="static")


# ---------------------------------------------------------------------------
# Modelos de datos
# ---------------------------------------------------------------------------
class ChatRequest(BaseModel):
    message: str
    session_id: str


class ChatResponse(BaseModel):
    response: str
    session_id: str


# ---------------------------------------------------------------------------
# Rutas
# ---------------------------------------------------------------------------
@app.get("/", include_in_schema=False)
async def root():
    """Sirve la interfaz de chat (index.html)."""
    return FileResponse("static/index.html")


@app.get("/health")
async def health():
    """Endpoint de salud para verificar que el servidor está activo."""
    return {"status": "ok", "service": "MedImage Chatbot"}


@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """Recibe un mensaje del usuario y retorna la respuesta del agente.

    - Guarda el mensaje y la respuesta en SQLite (memoria largo plazo).
    - El agente mantiene el historial de la sesión vía MemorySaver (memoria corto plazo).
    """
    if not request.message.strip():
        raise HTTPException(status_code=400, detail="El mensaje no puede estar vacío.")

    from agent import get_agent_response
    from database import guardar_mensaje

    try:
        # Guardar mensaje del usuario
        guardar_mensaje(request.session_id, "user", request.message)

        # Invocar al agente (ciclo ReAct automático)
        response = get_agent_response(request.message, request.session_id)

        # Guardar respuesta del asistente
        guardar_mensaje(request.session_id, "assistant", response)

        return ChatResponse(response=response, session_id=request.session_id)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error del agente: {str(e)}")


# ---------------------------------------------------------------------------
# Entrada directa
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,    # recarga automática al guardar archivos
        log_level="info",
    )
