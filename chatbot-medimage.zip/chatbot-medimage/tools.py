"""
tools.py — Las 6 herramientas @tool del agente MedImage.

IE1: 6 herramientas LangChain Core con tipado y docstring completo.
IE4: buscar_faq_resonancia usa RAG (FAISS) con metadato `fuente` para trazabilidad.
"""

import sqlite3
import requests
from datetime import datetime, timedelta
from langchain_core.tools import tool

from database import get_conn
from rag import get_retriever

# ---------------------------------------------------------------------------
# Datos del centro
# ---------------------------------------------------------------------------
HORARIO: dict[int, tuple[str, str]] = {
    0: ("08:00", "19:00"),  # Lunes
    1: ("08:00", "19:00"),  # Martes
    2: ("08:00", "19:00"),  # Miércoles
    3: ("08:00", "19:00"),  # Jueves
    4: ("08:00", "19:00"),  # Viernes
    5: ("09:00", "14:00"),  # Sábado
    # 6 = Domingo → sin atención
}


def _generar_slots(inicio: str, fin: str) -> list[str]:
    """Genera franjas horarias de 60 minutos entre inicio y fin."""
    h = datetime.strptime(inicio, "%H:%M")
    hfin = datetime.strptime(fin, "%H:%M")
    slots: list[str] = []
    while h + timedelta(hours=1) <= hfin:
        slots.append(h.strftime("%H:%M"))
        h += timedelta(hours=1)
    return slots


# ---------------------------------------------------------------------------
# Herramienta 1 — Horarios disponibles
# ---------------------------------------------------------------------------
@tool
def consultar_horarios_disponibles(fecha: str) -> str:
    """Consulta los horarios disponibles para agendar una cita en una fecha dada.

    Args:
        fecha: Fecha en formato YYYY-MM-DD (ej. '2026-11-15').

    Returns:
        Lista de horas libres o mensaje indicando que no hay atención ese día.
    """
    try:
        d = datetime.strptime(fecha, "%Y-%m-%d").date()
    except ValueError:
        return "Formato de fecha inválido. Use YYYY-MM-DD."

    if d.weekday() == 6:
        return f"El {fecha} es domingo. El centro no tiene atención ese día."

    if d.weekday() not in HORARIO:
        return f"No hay información de atención para el {fecha}."

    inicio, fin = HORARIO[d.weekday()]
    todos_slots = _generar_slots(inicio, fin)

    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT hora FROM citas WHERE fecha = ?", (fecha,))
    ocupados = {row[0] for row in c.fetchall()}
    conn.close()

    libres = [s for s in todos_slots if s not in ocupados]

    if not libres:
        return f"No hay horarios disponibles el {fecha}. Todos los bloques están ocupados."

    return f"Horarios disponibles el {fecha}: {', '.join(libres)} hrs."


# ---------------------------------------------------------------------------
# Herramienta 2 — Agendar cita
# ---------------------------------------------------------------------------
@tool
def agendar_cita(nombre: str, rut: str, fecha: str, hora: str, tipo_examen: str) -> str:
    """Agenda una cita médica para un paciente en el Centro MedImage.

    Args:
        nombre: Nombre completo del paciente.
        rut: RUT del paciente (ej. '12.345.678-9').
        fecha: Fecha de la cita en formato YYYY-MM-DD.
        hora: Hora de inicio del examen en formato HH:MM (ej. '10:00').
        tipo_examen: Tipo de examen ('resonancia' o 'TAC').

    Returns:
        Confirmación del agendamiento o mensaje de error si el horario ya está ocupado.
    """
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT id FROM citas WHERE fecha = ? AND hora = ?", (fecha, hora))
    if c.fetchone():
        conn.close()
        return (
            f"El horario {hora} del {fecha} ya está ocupado. "
            "Consulte otros horarios disponibles con la herramienta correspondiente."
        )

    c.execute(
        "INSERT INTO citas (nombre, rut, fecha, hora, tipo_examen) VALUES (?, ?, ?, ?, ?)",
        (nombre, rut, fecha, hora, tipo_examen),
    )
    conn.commit()
    conn.close()
    return (
        f"✅ Cita agendada exitosamente.\n"
        f"  Paciente : {nombre} (RUT {rut})\n"
        f"  Examen   : {tipo_examen}\n"
        f"  Fecha    : {fecha} a las {hora} hrs.\n"
        f"  Duración : 60 minutos\n\n"
        f"Recuerde traer su orden médica vigente."
    )


# ---------------------------------------------------------------------------
# Herramienta 3 — Cancelar cita
# ---------------------------------------------------------------------------
@tool
def cancelar_cita(rut: str, fecha: str) -> str:
    """Cancela una cita existente dado el RUT del paciente y la fecha de la cita.

    Args:
        rut: RUT del paciente.
        fecha: Fecha de la cita a cancelar en formato YYYY-MM-DD.

    Returns:
        Confirmación de cancelación o mensaje si no se encontró ninguna cita.
    """
    conn = get_conn()
    c = conn.cursor()
    c.execute("DELETE FROM citas WHERE rut = ? AND fecha = ?", (rut, fecha))
    eliminadas = c.rowcount
    conn.commit()
    conn.close()

    if eliminadas == 0:
        return f"No se encontró ninguna cita para RUT {rut} el {fecha}."
    return f"✅ Cita cancelada correctamente para RUT {rut} el {fecha}."


# ---------------------------------------------------------------------------
# Herramienta 4 — Consultar cita
# ---------------------------------------------------------------------------
@tool
def consultar_cita(rut: str) -> str:
    """Consulta todas las citas registradas de un paciente dado su RUT.

    Args:
        rut: RUT del paciente (ej. '12.345.678-9').

    Returns:
        Lista de citas activas para ese RUT o mensaje si no hay registros.
    """
    conn = get_conn()
    c = conn.cursor()
    c.execute(
        "SELECT fecha, hora, tipo_examen FROM citas WHERE rut = ? ORDER BY fecha, hora",
        (rut,),
    )
    citas = c.fetchall()
    conn.close()

    if not citas:
        return f"No hay citas registradas para el RUT {rut}."

    lineas = [f"Citas registradas para RUT {rut}:"]
    for fecha, hora, tipo in citas:
        lineas.append(f"  • {fecha} a las {hora} hrs — {tipo}")
    return "\n".join(lineas)


# ---------------------------------------------------------------------------
# Herramienta 5 — FAQ RAG (IE4)
# ---------------------------------------------------------------------------
@tool
def buscar_faq_resonancia(consulta: str) -> str:
    """Busca información relevante en el FAQ interno del Centro MedImage.

    Cubre preparación de exámenes, requisitos, políticas, horarios y servicios.
    Usa búsqueda semántica sobre el vector store FAISS interno.

    Args:
        consulta: Pregunta o tema a buscar (texto libre en español).

    Returns:
        Fragmentos del FAQ más relevantes con su fuente citada.
    """
    retriever = get_retriever()
    docs = retriever.invoke(consulta)

    if not docs:
        return "No se encontró información relevante en el FAQ interno."

    partes: list[str] = []
    for doc in docs:
        fuente = doc.metadata.get("fuente", "desconocida")
        partes.append(f"[{fuente}] {doc.page_content}")

    return "\n\n".join(partes)


# ---------------------------------------------------------------------------
# Herramienta 6 — Verificar feriados de Chile (IE4 API externa)
# ---------------------------------------------------------------------------
@tool
def verificar_feriados_chile(fecha: str) -> str:
    """Verifica si una fecha es feriado nacional en Chile consultando la API feriados.cl.

    Args:
        fecha: Fecha en formato YYYY-MM-DD.

    Returns:
        Indica si es feriado (con su nombre) o si hay atención normal ese día.
    """
    try:
        d = datetime.strptime(fecha, "%Y-%m-%d")
    except ValueError:
        return "Formato de fecha inválido. Use YYYY-MM-DD."

    year = d.year
    try:
        resp = requests.get(
            f"https://apis.digital.gob.cl/fl/feriados/{year}",
            timeout=6,
        )
        resp.raise_for_status()
        feriados = resp.json()

        for f in feriados:
            if f.get("fecha") == fecha:
                nombre = f.get("nombre", "feriado nacional")
                return (
                    f"El {fecha} es feriado nacional ({nombre}). "
                    "El Centro MedImage no tiene atención ese día. "
                    "[fuente: API_feriados_cl]"
                )

        return (
            f"El {fecha} no es feriado en Chile. "
            "Hay atención normal según el horario del centro. "
            "[fuente: API_feriados_cl]"
        )

    except requests.RequestException:
        return (
            "No se pudo verificar feriados (API no disponible en este momento). "
            "Proceda con precaución y confirme el feriado directamente."
        )
