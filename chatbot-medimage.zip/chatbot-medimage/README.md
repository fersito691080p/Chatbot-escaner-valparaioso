# Chatbot MedImage — Aplicación Web
**Centro de Resonancia y Scanner MedImage · Valparaíso**

Agente conversacional LangGraph para gestión de citas de exámenes de imágenes médicas.  
Esta versión corre como **aplicación Python local** con interfaz web — sin depender de Google Colab.

---

## Estructura del proyecto

```
chatbot-medimage/
├── main.py          ← Servidor FastAPI (rutas + lifespan)
├── agent.py         ← create_react_agent + MemorySaver
├── tools.py         ← 6 herramientas @tool
├── rag.py           ← Índice FAISS (FAQ interno)
├── database.py      ← SQLite (citas + historial)
├── requirements.txt
├── .env.example     ← Plantilla de claves API
└── static/
    └── index.html   ← Interfaz de chat web
```

---

## Instalación rápida

```bash
# 1. Clonar / descomprimir el proyecto y entrar a la carpeta
cd chatbot-medimage

# 2. Crear entorno virtual
python -m venv .venv
source .venv/bin/activate      # macOS / Linux
# .venv\Scripts\activate       # Windows

# 3. Instalar dependencias
pip install -r requirements.txt

# 4. Configurar claves API
cp .env.example .env
# Editar .env con tus claves reales (Groq + Gemini + LangSmith opcional)
```

---

## Ejecución

```bash
python main.py
```

El servidor arranca en **http://localhost:8000** y muestra:

```
[Startup] Inicializando base de datos…
[Startup] Cargando índice FAISS…          ← puede tardar ~10 s la primera vez
[Startup] Inicializando agente LangGraph…
[Startup] ✅ Sistema listo en http://localhost:8000
```

Abre el navegador en `http://localhost:8000` y comienza a chatear.

---

## Archivos generados en la primera ejecución

| Archivo | Descripción |
|---|---|
| `medimage.db` | SQLite con tablas `citas` e `historial_conversacion` |
| `faiss_index/` | Índice FAISS del FAQ interno (se reconstruye si se borra) |

---

## API

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/` | Interfaz de chat (index.html) |
| GET | `/health` | Estado del servidor |
| POST | `/chat` | Invocar al agente |

**Body de `/chat`:**
```json
{ "message": "Quiero agendar una resonancia", "session_id": "uuid-de-la-sesion" }
```

**Respuesta:**
```json
{ "response": "Con gusto te ayudo…", "session_id": "uuid-de-la-sesion" }
```

---

## Claves API necesarias

| Variable | Servicio | URL |
|---|---|---|
| `GROQ_API_KEY` | LLM (inferencia) | https://console.groq.com |
| `GEMINI_API_KEY` | Embeddings FAISS | https://aistudio.google.com |
| `LANGSMITH_API_KEY` | Trazabilidad (opcional) | https://smith.langchain.com |

---

## Tecnologías

| Componente | Tecnología |
|---|---|
| Servidor | FastAPI + Uvicorn |
| Agente | LangGraph `create_react_agent` |
| Herramientas | LangChain Core `@tool` (×6) |
| Memoria corto plazo | LangGraph `MemorySaver` |
| Memoria largo plazo | SQLite |
| RAG | FAISS + Gemini Embeddings |
| LLM | Groq |
| Frontend | HTML/CSS/JS vanilla |

---

## Autor

Sebastián — ISY0101 EP2, Duoc UC Valparaíso, Octubre 2026
