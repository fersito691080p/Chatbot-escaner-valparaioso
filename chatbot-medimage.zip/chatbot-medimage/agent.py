"""
agent.py — Agente LangGraph del chatbot MedImage.

IE2: create_react_agent de langgraph.prebuilt (reemplaza el loop ReAct manual).
IE3: MemorySaver como checkpointer (memoria corto plazo por thread_id).
IE5: Ciclo ReAct automático vía grafo LangGraph.
"""

import os
from langchain_groq import ChatGroq
from langgraph.prebuilt import create_react_agent
from langgraph.checkpoint.memory import MemorySaver
from langchain_core.messages import HumanMessage

from tools import (
    consultar_horarios_disponibles,
    agendar_cita,
    cancelar_cita,
    consultar_cita,
    buscar_faq_resonancia,
    verificar_feriados_chile,
)

# ---------------------------------------------------------------------------
# System prompt del agente
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """Eres el asistente virtual del Centro de Resonancia y Scanner MedImage, \
ubicado en Av. Colón 2383, Valparaíso, Chile.

Tu función es ayudar a los pacientes a:
- Consultar horarios disponibles para exámenes de imágenes
- Agendar, consultar o cancelar citas
- Responder preguntas sobre preparación de exámenes (resonancia magnética y TAC)
- Informar sobre políticas del centro, requisitos y servicios

REGLAS IMPORTANTES:
- Horario de atención: Lunes a Viernes 08:00–19:00 / Sábados 09:00–14:00
- Sin atención domingos ni feriados nacionales
- SIEMPRE verifica si la fecha es feriado antes de consultar horarios disponibles
- Para TAC con contraste IV: informa sobre ayuno de 4 horas y creatinina sérica reciente
- Toda cita requiere orden médica vigente
- Cada examen ocupa un bloque de 60 minutos

Responde siempre en español, de forma amable y profesional. \
Usa las herramientas disponibles para responder con información actualizada y precisa. \
Si el usuario menciona síntomas o dudas médicas, recomiéndele consultar con su médico tratante."""

# ---------------------------------------------------------------------------
# Singletons: un agente y un checkpointer para toda la app
# ---------------------------------------------------------------------------
_checkpointer = MemorySaver()
_agent = None


def _build_agent():
    """Construye el agente LangGraph. Se llama solo una vez."""
    llm = ChatGroq(
        model=os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile"),
        temperature=0,
        api_key=os.getenv("GROQ_API_KEY"),
    )

    herramientas = [
        consultar_horarios_disponibles,
        agendar_cita,
        cancelar_cita,
        consultar_cita,
        buscar_faq_resonancia,
        verificar_feriados_chile,
    ]

    return create_react_agent(
        model=llm,
        tools=herramientas,
        prompt=SYSTEM_PROMPT,
        checkpointer=_checkpointer,
    )


def get_agent():
    """Retorna el agente (singleton). Lo construye si aún no existe."""
    global _agent
    if _agent is None:
        _agent = _build_agent()
    return _agent


def get_agent_response(message: str, session_id: str) -> str:
    """Invoca el agente con un mensaje de usuario y retorna su respuesta final.

    Args:
        message:    Texto del usuario.
        session_id: Identificador único de la sesión (thread_id para MemorySaver).

    Returns:
        Contenido del último AIMessage del agente.
    """
    agent = get_agent()
    config = {"configurable": {"thread_id": session_id}}

    result = agent.invoke(
        {"messages": [HumanMessage(content=message)]},
        config=config,
    )

    return result["messages"][-1].content
